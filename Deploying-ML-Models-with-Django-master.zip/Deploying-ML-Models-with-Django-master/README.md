# Deploying-ML-Models-with-Django
A medium article tutorial on how I deploy a machine learning model with django

Article: https://medium.com/@aminuisrael2/deploying-ml-models-using-django-rest-api-part-2-84cea50b3c83
